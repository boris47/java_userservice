import { CommonModule } from "@angular/common";
import { type OnInit, Component, Input } from "@angular/core";
import { type IDialogBaseData, BaseDialogComponent } from "@components/global-dialog/global-dialog.component";

interface IConfirmDialog extends IDialogBaseData
{
	onConfirm(): any;
	onCancel(): any;
}

@Component({
	selector: 'global-modal-confirm',
	standalone: true,
	imports: [CommonModule],
	templateUrl: 'global-dialog-confirm.component.html',
})
export class GlobalDialogConfirm extends BaseDialogComponent<IConfirmDialog, boolean> implements OnInit
{
	onConfirm?: () => any;
	onCancel?: () => any;
	
	ngOnInit(): void
    {
        this.title = this.data!.title;
        this.message = this.data!.message;
		this.onConfirm = this.data!.onConfirm;
		this.onCancel = this.data!.onCancel;
    }
	
	override onClose(result: boolean): void
	{
		console.log("GlobalDialogConfirm:onClose");
		
		result && this.onConfirm?.() || this.onCancel?.();
	}
}
