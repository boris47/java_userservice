import { CommonModule } from "@angular/common";
import { Component, type Type, ViewContainerRef, viewChild, type ComponentRef } from "@angular/core";

export interface IDialogBaseData
{
	title: string;
	message: string;
}

export abstract class BaseDialogComponent<TInput = void, TResult = any> implements IDialogBaseData
{
	title: string = '';
	message: string = '';
	
	data?: TInput;
	
	public close(result?: TResult): void
	{
		// custom close logic here
		
		this.onClose(result);
	}
	
	protected onClose(result?: TResult): void
	{
		
	}
}

@Component({
	selector: 'app-global-dialog',
	template: `<div class="modal">
		<ng-container #globalDialogContainer></ng-container>
	</div>`,
	imports: [CommonModule]
})
export default class GlobalDialogComponent
{
	container = viewChild.required('globalDialogContainer', { read: ViewContainerRef });

	open
	<T extends IDialogBaseData, C extends BaseDialogComponent<T>, D extends C['data']>
	(component: Type<C>, data: D): C | null
	{
		const container = this.container();
		console.assert(container, "container is null");
		if (container)
		{
			container.clear();
			const ref = container.createComponent(component);
			console.assert(ref, "ref is null");
			if (ref)
			{
				ref.instance.data = data;
				
				const prevClose = ref.instance.close;
				ref.instance.close = (args?: any) =>
				{
					console.log("GlobalDialogComponent (ref.instance.close)", args);
					container.clear();
					prevClose.call(ref.instance, args);
				}
				
				return ref.instance;
			}
		}
		return null;
	}
}
