import { CommonModule } from "@angular/common";
import { type OnInit, Component } from "@angular/core";
import { type IDialogBaseData, BaseDialogComponent } from "@components/global-dialog/global-dialog.component";


@Component({
	selector: 'global-modal-confirm',
	standalone: true,
	imports: [CommonModule],
	templateUrl: 'global-dialog-infos.component.html',
})
export class GlobalDialogInfos extends BaseDialogComponent<IDialogBaseData, void> implements OnInit
{
	ngOnInit(): void
    {
        this.title = this.data!.title;
        this.message = this.data!.message;
    }
	
	override onClose(result?: void): void
	{
		console.log("GlobalDialogInfos:onClose");
	}
}
