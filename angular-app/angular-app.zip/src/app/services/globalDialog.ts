import { Injectable, type Type, HostListener } from "@angular/core";
import type { BaseDialogComponent, IDialogBaseData } from "@components/global-dialog/global-dialog.component";
import type GlobalDialogComponent from "@components/global-dialog/global-dialog.component";


@Injectable({ providedIn: 'root' })
export class DialogService
{
	private dialogRef!: GlobalDialogComponent;
	private dialogOpen = false;
	
	register(dialog: GlobalDialogComponent)
	{
		this.dialogRef = dialog;
	}
	
	open<T extends IDialogBaseData, C extends BaseDialogComponent<T>, D extends C['data']>(component: Type<C>, data: D)
	{
		const dialogInstance = this.dialogRef.open(component, data);
		if (dialogInstance)
		{
			this.dialogOpen = true;
			const prevClose = dialogInstance.close;
			dialogInstance.close = (args?: any) =>
			{
				console.log("DialogService:open (dialogInstance.close)", args);
				this.dialogOpen = false;
				prevClose.call(dialogInstance, args);
			}
		}
	}
	
	isDialogOpen(): boolean
	{
		return this.dialogOpen;
	}
	
	@HostListener('window:beforeunload', ['$event'])
	handleBeforeUnload(event: BeforeUnloadEvent)
	{
		if (this.dialogOpen)
		{
			alert("A dialog is open !!");
			event.preventDefault();
			event.returnValue = ''; // Required for Chrome
			return false;
		}
		return true;
	}
}
