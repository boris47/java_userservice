import { ComponentFixture, TestBed } from '@angular/core/testing';
import RootComponent from './root.component';
import { CommonModule } from '@angular/common';
import { RouterOutlet } from '@angular/router';

describe('RootComponent', () =>
{
	let fixture: ComponentFixture<RootComponent>;
	let component: RootComponent;

	beforeEach(async () =>
	{
		await TestBed.configureTestingModule({
			imports: [CommonModule, RouterOutlet]
		}).compileComponents();

		fixture = TestBed.createComponent(RootComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it('should create the app', () =>
	{
		expect(component).toBeTruthy();
	});
});
